import { Sequelize, DataTypes } from "sequelize";

// Initialize Sequelize instance
const sequelize = new Sequelize("mysql://root:PrlbAsNlCzSEKbuhwfoZcJzIPqXtzhcJ@junction.proxy.rlwy.net:18909/railway", {
  dialect: "mysql",
});

// Admin Model
export const Admin = sequelize.define(
  "Admin",
  {
    id: {
      type: DataTypes.STRING,
      primaryKey: true,
      defaultValue: Sequelize.UUIDV4,
    },
    username: DataTypes.STRING,
    password: DataTypes.STRING,
    loginId: {
      type: DataTypes.STRING,
      unique: true,
    },
    salary: DataTypes.STRING,
    userType: {
      type: DataTypes.ENUM("ADMIN", "SUPERADMIN"),
    },
  },
  { tableName: "admin", timestamps: false }
);

// AdminJwt Model
export const AdminJwt = sequelize.define(
  "AdminJwt",
  {
    id: {
      type: DataTypes.STRING,
      primaryKey: true,
      defaultValue: Sequelize.UUIDV4,
    },
    adminId: {
      type: DataTypes.STRING,
      unique: true,
    },
    accessToken: DataTypes.STRING,
    refreshToken: DataTypes.STRING,
    accessTokenExpiryDate: DataTypes.DATE,
    refreshTokenExpiryDate: DataTypes.DATE,
  },
  { tableName: "admin_jwt", timestamps: false }
);

Admin.hasOne(AdminJwt, { foreignKey: "adminId" });
AdminJwt.belongsTo(Admin, { foreignKey: "adminId" });

// Purchase Model
export const Purchase = sequelize.define(
  "Purchase",
  {
    id: {
      type: DataTypes.STRING,
      primaryKey: true,
      defaultValue: Sequelize.UUIDV4,
    },
    purchaseName: DataTypes.STRING,
    supplierId: DataTypes.STRING,
    supplierLorryId: DataTypes.STRING,
    purchaseStatus: {
      type: DataTypes.ENUM("PENDING", "COMPLETED", "CANCELLED", "OUTSTANDING"),
    },
    purchaseDate: DataTypes.DATE,
  },
  { tableName: "purchase", timestamps: false }
);

// Other models
export const PurchaseInvoice = sequelize.define(
  "PurchaseInvoice",
  {
    id: {
      type: DataTypes.STRING,
      primaryKey: true,
      defaultValue: Sequelize.UUIDV4,
    },
    image: DataTypes.BLOB,
    purchaseId: DataTypes.STRING,
  },
  { tableName: "purchase_invoice", timestamps: false }
);

export const PurchaseInfo = sequelize.define(
  "PurchaseInfo",
  {
    id: {
      type: DataTypes.STRING,
      primaryKey: true,
      defaultValue: Sequelize.UUIDV4,
    },
    pricePerKg: DataTypes.STRING,
    kgPurchased: DataTypes.STRING,
    totalPurchasePrice: DataTypes.FLOAT,
    durianVarietyId: DataTypes.STRING,
    purchaseId: DataTypes.STRING,
  },
  { tableName: "purchase_info", timestamps: false }
);

export const Supplier = sequelize.define(
  "Supplier",
  {
    id: {
      type: DataTypes.STRING,
      primaryKey: true,
      defaultValue: Sequelize.UUIDV4,
    },
    companyName: DataTypes.STRING,
    contact: DataTypes.STRING,
    date: DataTypes.DATE,
  },
  { tableName: "supplier", timestamps: false }
);

export const SupplierLorry = sequelize.define(
  "SupplierLorry",
  {
    id: {
      type: DataTypes.STRING,
      primaryKey: true,
      defaultValue: Sequelize.UUIDV4,
    },
    lorryPlateNumber: DataTypes.STRING,
    supplierId: DataTypes.STRING,
  },
  { tableName: "supplier_lorry", timestamps: false }
);

export const Sales = sequelize.define(
  "Sales",
  {
    id: {
      type: DataTypes.STRING,
      primaryKey: true,
      defaultValue: Sequelize.UUIDV4,
    },
    companyName: DataTypes.STRING,
    salesStatus: {
      type: DataTypes.ENUM("PENDING", "COMPLETED", "CANCELLED", "OUTSTANDING"),
    },
    salesDate: DataTypes.DATE,
  },
  { tableName: "sales", timestamps: false }
);

export const SalesInvoice = sequelize.define(
  "SalesInvoice",
  {
    id: {
      type: DataTypes.STRING,
      primaryKey: true,
      defaultValue: Sequelize.UUIDV4,
    },
    image: DataTypes.BLOB,
    salesId: DataTypes.STRING,
  },
  { tableName: "sales_invoice", timestamps: false }
);

export const SalesInfo = sequelize.define(
  "SalesInfo",
  {
    id: {
      type: DataTypes.STRING,
      primaryKey: true,
      defaultValue: Sequelize.UUIDV4,
    },
    pricePerKg: DataTypes.STRING,
    kgSales: DataTypes.STRING,
    totalSalesValue: DataTypes.FLOAT,
    durianVarietyId: DataTypes.STRING,
    salesId: DataTypes.STRING,
  },
  { tableName: "sales_info", timestamps: false }
);

export const DurianVariety = sequelize.define(
  "DurianVariety",
  {
    id: {
      type: DataTypes.STRING,
      primaryKey: true,
      defaultValue: Sequelize.UUIDV4,
    },
    durianCode: {
      type: DataTypes.STRING,
      unique: true,
    },
    stockQuantity: DataTypes.INTEGER,
  },
  { tableName: "DurianVariety", timestamps: false }
);

export const SalaryAdvanced = sequelize.define(
  "SalaryAdvanced",
  {
    id: {
      type: DataTypes.STRING,
      primaryKey: true,
      defaultValue: Sequelize.UUIDV4,
    },
    adminId: DataTypes.STRING,
    salaryAdvancedAmount: DataTypes.FLOAT,
    outstandingAmount: DataTypes.FLOAT,
    requestDate: DataTypes.DATE,
  },
  { tableName: "salary_advanced", timestamps: false }
);

export const Bucket = sequelize.define(
  "Bucket",
  {
    id: {
      type: DataTypes.STRING,
      primaryKey: true,
      defaultValue: Sequelize.UUIDV4,
    },
    kg: DataTypes.FLOAT,
    salesInfoId: DataTypes.STRING,
    purchaseInfoId: DataTypes.STRING,
  },
  { tableName: "bucket", timestamps: false }
);

export const Expenses = sequelize.define(
  "Expenses",
  {
    id: {
      type: DataTypes.STRING,
      primaryKey: true,
      defaultValue: Sequelize.UUIDV4,
    },
    expensesType: {
      type: DataTypes.ENUM(
        "TRANSPORTATION",
        "ERP",
        "GSTSINGAPORE",
        "MAINTENANCE",
        "PETROL",
        "SALARY",
        "CARRENTAL",
        "FOOD",
        "OTHERS"
      ),
    },
    expensesAmount: DataTypes.FLOAT,
    remark: DataTypes.STRING,
    date: DataTypes.DATE,
  },
  { tableName: "expenses", timestamps: false }
);
